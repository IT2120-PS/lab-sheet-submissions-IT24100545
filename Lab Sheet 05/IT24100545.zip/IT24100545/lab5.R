setwd("C:\\Users\\it24100545\\Desktop\\IT24100545")
getwd()

delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)

fix(delivery_times)

attach(delivery_times)

names(delivery_times)<-("minutes")

attach(delivery_times)

histogram<-hist(minutes,main="Histogram for Delivery Times in minutes",breaks=seq(20,70,length=9),right=FALSE)

breaks<-round(histogram$breaks)

freq<-histogram$mids

cum.freq<-cumsum(freq)

new<-c()

for (i in 1:length(breaks)){
  if (i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]}
}

plot(breaks,new,type='l',main="cumulative Frequwncy polygon for Delivery times",xlab="Minutes",ylab="cumulative Frequency",ylim=c(0,max(cum.freq)))
